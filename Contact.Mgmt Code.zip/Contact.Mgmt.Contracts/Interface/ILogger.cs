﻿
using System;
using System.Collections.Generic;
using Contact.Mgmt.Models;

namespace Contact.Mgmt.Contracts
{
    public interface ILogger
    {
        IEnumerable<AppException> Get();
        long Log(Exception ex, string uid);
        long Log(string Info, string uid);
        long Log(AppException ex);
    }
}
