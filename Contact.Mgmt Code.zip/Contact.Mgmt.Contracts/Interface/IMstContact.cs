﻿
using Contact.Mgmt.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact.Mgmt.Contracts
{
    public interface IMstContact
    {
        long GetMaxId();
        bool AddContact(MstContact contact);
        bool CheckContactExists(string FirstName, string LastName);
        bool DeleteContact(long Id);
        MstContact GetContact(long Id);
        IList<MstContact> GetAllContacts();
        bool UpdateContact(MstContact contact);
    }
}
