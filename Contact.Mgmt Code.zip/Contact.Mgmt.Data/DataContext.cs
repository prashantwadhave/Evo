﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contact.Mgmt.Contracts;
using System.Data.Entity;
using Contact.Mgmt.Models;
using System.Configuration;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace Contact.Mgmt.Data
{
    public class DataContext : DbContext, IDataContext
    {

        public DbSet<AppException> AppException { get; set; }

        public DbSet<MstContact> MstContact { get; set; }


        public DataContext() : base(ConnenctionStringProject)
        {
            Database.SetInitializer<DataContext>(null);
        }

        public static string ConnenctionStringProject
        {
            get
            {
                return Convert.ToString(ConfigurationManager.ConnectionStrings["CoreDataContext"].ToString());
            }
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }
}
