﻿using Contact.Mgmt.Models;
using Contact.Mgmt.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact.Mgmt.Services
{
    public class ContactService : IMstContact
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IGenericRepository<MstContact> _ContactRepository = null;

        public ContactService(IUnitOfWork uow)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _ContactRepository = _uow.GetRepository<MstContact>();
        }

        public long GetMaxId()
        {
            return _ContactRepository.Get().Max(x => x.Id) + 1;
        }

        public bool AddContact(MstContact contact)
        {
            contact.ModifiedDate = DateTime.Now;
            contact.Id = this.GetMaxId();
            _ContactRepository.Add(contact);
            return this.CommintToDB();
        }

        public bool CheckContactExists(string FirstName,string LastName)
        {
            return _ContactRepository.Get().Where(x => x.FirstName.ToLower().Trim() == FirstName.ToLower().Trim() && x.LastName.ToLower().Trim()==LastName.ToUpper().Trim()).Any();
        }
       
        public bool DeleteContact(long Id)
        {
            bool status = false;
            MstContact existingContact = this.GetContact(Id);

            if (existingContact != null)
            {
                _ContactRepository.Delete(existingContact);
                status = this.CommintToDB();
            }

            return status;
        }

        public MstContact GetContact(long Id)
        {
            return _ContactRepository.Get().FirstOrDefault(x => x.Id == Id);
        }

        public IList<MstContact> GetAllContacts()
        {
            var result = _ContactRepository.Get().ToList();

            return result;
        }

        public bool UpdateContact(MstContact contact)
        {
            bool status = false;
            MstContact existingContact = this.GetContact(contact.Id);

            if (existingContact != null)
            {
                existingContact.FirstName = contact.FirstName;
                existingContact.LastName = contact.LastName;
                existingContact.PhoneNumber = contact.PhoneNumber;
                existingContact.Email = contact.Email;
                existingContact.ModifiedDate = DateTime.Now;

                _ContactRepository.Update(existingContact);
                status = this.CommintToDB();
            }

            return status;
        }
        
        private bool CommintToDB()
        {
            return _uow.Commit();
        }
        
    }
}
