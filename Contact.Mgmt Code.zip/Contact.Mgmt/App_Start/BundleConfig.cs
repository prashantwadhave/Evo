﻿using System.Web;
using System.Web.Optimization;

namespace Contact.Mgmt
{
    public class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").
                Include("~/Scripts/jquery-{version}.js",
                        "~/Scripts/knockout-3.4.2.debug.js",
                        "~/Scripts/knockout.validation.js",
                        "~/Scripts/bootstrap.min.js",
                        "~/Scripts/sammy_template.js",
                        "~/Scripts/sammy-0.7.5.min.js",
                        "~/Scripts/app.js",
                        "~/Scripts/jquery.validate.min.js",
                        "~/Scripts/modernizr-2.6.2.js",
                        "~/Scripts/DataTable_KO/datatables.min.js",
                        "~/Scripts/DataTable_KO/bindingForDataTable.js",
                        "~/Scripts/Common/Common.js"
                       
                        ));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at https://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/site.css",
                      "~/Content/dataTables.bootstrap.css",
                      "~/Content/jquery.dataTables.min.css",
                      "~/Content/buttons.dataTables.min.css"


                      ));
        }
    }
}
