﻿using Contact.Mgmt.Contracts;
using Contact.Mgmt.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Contact.Mgmt.Core
{
    public class ContactController : ApiController
    {
        private  IMstContact _ContactService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public ContactController(IMstContact contactService)
        {
            _ContactService = contactService;
            
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        public HttpResponseMessage GetAllContact()
        {
            //long tt1 = 0;
            //long tt = 23 /tt1;
            IList<MstContact> lstContact = _ContactService.GetAllContacts();
            return Request.CreateResponse(HttpStatusCode.OK, lstContact);
        }

        [HttpPost]
        public HttpResponseMessage AddContact(MstContact contact)
        {
            var result = _ContactService.AddContact(contact);
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }

        [HttpPost]
        public HttpResponseMessage UpdateContact(MstContact contact)
        {
            var result = _ContactService.UpdateContact(contact);
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }

        [HttpGet]
        public HttpResponseMessage DeleteContact(long Id)
        {
            var result = _ContactService.DeleteContact(Id);
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }
    }
}
