﻿using Contact.Mgmt.Contracts;
using Contact.Mgmt.Models;
using Contact.Mgmt.Services;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;

namespace Contact.Mgmt
{
    public class LogExceptionAttribute : ExceptionHandler
    {
        private readonly ILogger logger;

        public LogExceptionAttribute() : this((ILogger)GlobalConfiguration.Configuration.DependencyResolver.GetService(typeof(ILogger)))
        {

        }

        public LogExceptionAttribute(ILogger logger)
        {
            this.logger = logger;
        }

        public override void Handle(ExceptionHandlerContext context)
        {

            try
            {
                var empInfo = HttpContext.Current.User.Identity.Name;
                long logged = logger.Log(context.Exception, empInfo);

                context.Result = new TextPlainErrorResult
                {
                    Request = context.ExceptionContext.Request,
                    Content = logged.ToString() + ":" + context.Exception.Message
                };
            }
            catch (Exception ex)
            {
                LogInTextFile("Error - " + DateTime.Now.ToString("dd MMM yyyy hh:mm:ss tt") + " - " + ex.Message + " - " + ex.StackTrace);
            }
        }

        private void LogInTextFile(string info)
        {
            try
            {
                var dir = System.Web.HttpContext.Current.Server.MapPath("~\\LogFiles");
                string fileName = dir + "\\" + DateTime.Now.ToString("ddMMMyyyy") + ".log";

                string logInfo = "Exception : " + DateTime.Now.ToString("dd MMM yyyy hh:mm:ss tt") + " : " + info;

                FileInfo fi = new FileInfo(fileName);
                if (!fi.Exists)
                {
                    //Create a file to write to.
                    using (StreamWriter sw = File.CreateText(fi.FullName))
                    {
                        sw.WriteLine(logInfo);
                    }
                }
                else
                {
                    using (StreamWriter sw = File.AppendText(fi.FullName))
                    {
                        sw.WriteLine(logInfo);
                    }
                }
            }
            catch
            { }

        }



        private class TextPlainErrorResult : IHttpActionResult
        {
            public HttpRequestMessage Request { get; set; }

            public string Content { get; set; }

            public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
            {
                HttpResponseMessage response =
                                 new HttpResponseMessage(HttpStatusCode.InternalServerError)
                                 {
                                     Content = new StringContent(Content),
                                     RequestMessage = Request
                                 };
                return Task.FromResult(response);
            }
        }
    }

}