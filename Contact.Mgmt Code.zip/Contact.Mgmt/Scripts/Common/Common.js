﻿var Commonmethods = {
    AjaxData: function GetData(url, reqType, isAsync, contentType, data, ErrorMsg, successCallback) {

        var result = null;
        if (contentType.trim() == '')
            contentType = "application/x-www-form-urlencoded; charset=UTF-8";

        $.ajax({
            url: url,
            type: reqType,
            async: isAsync,
            dataType: "json",
            contentType: contentType,
            data: data,
            success: successCallback,
            error: function (r, s, e) {
                $('#cmnMsgText').text(ErrorMsg);
                $(".message_popup").show();
            }
        });
    },

    PostAjaxData: function PostData(url, reqType, isAsync, contentType, data, ErrorMsg, successCallback) {

        var result = null;
        if (contentType.trim() == '')
            contentType = "application/json;charset=utf-8";

        $.ajax({
            url: url,
            type: reqType,
            async: isAsync,
            dataType: "json",
            contentType: contentType,
            data: data,
            success: successCallback,
            error: function (r, s, e) {
                $('#cmnMsgText').text(ErrorMsg);
                $(".message_popup").show();
            }
        });
    }
};