﻿function contactViewModel() {
    var self = this;

    self.Id = ko.observable();
    self.FirstName = ko.observable();
    self.LastName = ko.observable();
    self.PhoneNumber = ko.observable();
    self.Email = ko.observable();
    self.Status = ko.observable();
    self.ListContacts = ko.observableArray();
    self.selectedContactIdInGrid = ko.observable();
    self.ViewContactVisible = ko.observable(true);
    self.AddContactVisible = ko.observable(false);
    self.addHeadingVisible = ko.observable(false);
    self.updateHeadingVisible = ko.observable(false);
    self.PopupMessage = ko.observable();
    


    self.ViewContact = function () {
        self.GetInitialData();
        $("#dvViewAllContact").show();
        $("#dvAddContact").hide();
        $("#addHeadingVisible").hide();
        $("#updateHeadingVisible").hide();
        $("#updateButton").show();
        $("#addButton").show();
        $(".deleteButton").show();
    }

    self.AddContact = function () {
        $("#dvViewAllContact").hide();
        $("#dvAddContact").show();
        $("#addHeadingVisible").show();
        $("#updateHeadingVisible").hide();
        $(".updateButton").hide();
        $(".deleteButton").hide();
        $(".addButton").show();
        self.Reset();
    }

    self.UpdateContact = function () {
        $("#dvViewAllContact").hide();
        $("#dvAddContact").show();
        $("#addHeadingVisible").hide();
        $("#updateHeadingVisible").show();
        $(".addButton").hide();
        $(".deleteButton").hide();
        $(".updateButton").show();

    }

    self.GetInitialData = function () {

        var url = '/api/contact/getallcontact';

        Commonmethods.AjaxData(url, 'GET', false, '', '', 'Get Master Data Error', function (result) {
            if (result != null) {
                if (result.length > 0) {
                    self.ListContacts(result);

                    $.fn.modal.Constructor.prototype.enforceFocus = function () { };
                }

            } else {
                var msg = "No Data Found."
                $('#successMsg').text(msg);
                $(".popup_for_disp_msg").show();
            }
        });
    };

    self.rowClick = function (row) {
        self.selectedContactIdInGrid(row.Id);
        self.Id(row.Id);
        self.FirstName(row.FirstName);
        self.LastName(row.LastName);
        self.PhoneNumber(row.PhoneNumber);
        self.Email(row.Email);
        self.Status(row.Status);
    }

    self.SaveContact = function () {
        if (self.errors.length == 0) {
            var contact = {
                FirstName: self.FirstName(),
                LastName: self.LastName(),
                PhoneNumber: self.PhoneNumber(),
                Email: self.Email(),
                Status: self.Status()
            };

            Commonmethods.PostAjaxData('/api/Contact/AddContact', 'POST', false, '', ko.toJSON(contact), 'Unable to add contact', function (result) {
                if (result) {
                    self.PopupMessage("Contact added successfully.");
                    $(".popup_for_disp_msg").show();
                }
                else {
                    self.PopupMessage("Failed to add contact.");
                    $(".popup_for_disp_msg").show();
                }
                self.ViewContact();
            });
        }
        else {
            self.errors.showAllMessages();
        }
    }

    self.UpdatesContact = function () {
        if (self.errors.length == 0) {
            var contact = {
                Id: self.Id(),
                FirstName: self.FirstName(),
                LastName: self.LastName(),
                PhoneNumber: self.PhoneNumber(),
                Email: self.Email(),
                Status: self.Status()
            };

            Commonmethods.PostAjaxData('/api/Contact/UpdateContact', 'POST', false, '', ko.toJSON(contact), 'Unable to add contact', function (result) {
                if (result) {
                    self.PopupMessage("Contact updated successfully.");
                    $(".popup_for_disp_msg").show();
                }
                else {
                    self.PopupMessage("Failed to update contact.");
                    $(".popup_for_disp_msg").show();
                }
                self.ViewContact();
            });
        }
        else {
            self.errors.showAllMessages();
        }
    }    

    self.DeleteContact = function () {
        var userSelected = self.selectedContactIdInGrid();
        var msg = "Are you sure?"
        $('#cmnMsg').text(msg);

        if (userSelected == undefined || userSelected == null || userSelected == '') {
            self.PopupMessage("Please select one record to delete.");
            $(".popup_for_disp_msg").show();
        } else {
            $(".confirmation_popupnew").show();
        }
    }

    self.OkConfirmation = function () {
        Commonmethods.AjaxData('/api/contact/deletecontact?Id=' + self.selectedContactIdInGrid(), 'GET', false, '', '', 'Get Master Data Error', function (result) {
            if (result == true) {
                self.PopupMessage("Contact deleted successfully.");
                $(".popup_for_disp_msg").show();
            } else {
                self.PopupMessage("Contact cannot be deleted.");
                $(".popup_for_disp_msg").show();
            }

            $(".confirmation_popupnew").hide();
            self.ViewContact();
        });
    };

    self.CancelConfirmation = function () {
        $(".confirmation_popupnew").hide();
    }

    self.HidetrueMsg = function () {
        $(".popup_for_disp_msg").hide();
    };

    self.Reset = function () {
        
        self.FirstName('');
        self.LastName('');
        self.PhoneNumber('');
        self.Email('');
        self.Status(false);
        self.selectedContactIdInGrid(null);
        self.errors.showAllMessages(false);
    }

    self.FirstName.extend({
        required: {
            param: true,
            message: "Please enter first name."
        }
    });

    self.LastName.extend({
        required: {
            param: true,
            message: "Please enter last name."
        }
    });

    self.PhoneNumber.extend({
        required: {
            param: true,
            message: "Please enter phone number name."
        }
    });

    self.Email.extend({
        required: {
            param: true,
            message: "Please enter email name."
        },
        pattern: {
            message: 'Invalid email format.',
            params: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        }
    });

    let ValidationFields = [self.FirstName, self.LastName, self.PhoneNumber, self.Email];
    self.errors = ko.validation.group(ValidationFields);
};


$(document).ready(function () {


    ko.validation.registerExtenders();
    var knockoutValidationSettings = {
        registerExtenders: true,
        insertMessages: true,
        decorateElement: true,
        errorMessageClass: 'error',
        messagesOnModified: true,
        decorateElementOnModified: true,
        decorateInputElement: true
    };
    ko.validation.init(knockoutValidationSettings, true);

    var contactviewmodel = new contactViewModel();
    ko.applyBindings(contactviewmodel, document.getElementById('MainContact'));

    contactviewmodel.GetInitialData();
    contactviewmodel.errors.showAllMessages(false);
});