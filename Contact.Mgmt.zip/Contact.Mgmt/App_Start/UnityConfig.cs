using Contact.Mgmt.Contracts;
using Contact.Mgmt.Data;
using Contact.Mgmt.Repositories;
using Contact.Mgmt.Services;
using System.Web.Http;
using Unity;
using Unity.WebApi;

namespace Contact.Mgmt
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            // e.g. container.RegisterType<ITestService, TestService>();
            container.RegisterType<IUnitOfWork, UnitOfWork>(new Unity.Lifetime.PerResolveLifetimeManager());
            container.RegisterType<IDataContext, DataContext>();
            container.RegisterType<ILogger, ExceptionLoggerService>();
            container.RegisterType<IMstContact, ContactService>();
            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}