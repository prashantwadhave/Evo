﻿var app = $.sammy("#mainContent", function () {
    this.use('Template');
    this.get('#/ViewContacts', function (context) {
        context.app.swap('');
        context.render('Templates/ViewContacts.html').appendTo(context.$element());        
    });

    this.get('#/AddContact', function (context) {
        context.app.swap('');
        context.render('Templates/AddContact.html').appendTo(context.$element()); 
    });

    this.get('#/UpdateContact', function (context) {
        context.app.swap('');
        context.render('Templates/UpdateContact.html').appendTo(context.$element());
    });
});

$(function () {
    try {
        app.run('#/ViewContacts');
    } catch (e) {
        logError(e, "Exception raised in App.js");
    }
});